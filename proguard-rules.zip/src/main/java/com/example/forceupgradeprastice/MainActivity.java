package com.example.forceupgradeprastice;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public static String url = "http://104.237.10.23:8080/test/A1.apk";
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.bt_install).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DownloadApk(MainActivity.this,"V1.apk").execute();
//                install();
            }
        });
        if(
                ContextCompat.checkSelfPermission(this,Manifest.permission.REQUEST_INSTALL_PACKAGES) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this,Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED
        ){
            String [] str = {
                    Manifest.permission.REQUEST_INSTALL_PACKAGES,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.INTERNET
            };
            requestPermissions(str,11);
        }
    }

    void install(String location){
        File toInstall = new File(location);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri apkUri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            apkUri = FileProvider.getUriForFile(MainActivity.this,
                    MainActivity.this.getPackageName() + ".provider", toInstall);
        } else {
            apkUri = Uri.fromFile(toInstall);
        }
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);
    }

    class DownloadApk extends AsyncTask<String, Integer,Boolean>{

        Context context;
        String fileName;
        ProgressDialog dialog;
        DownloadApk(Context context,String fileName){
            this.context = context;
            this.fileName = fileName;
        }
        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            dialog.dismiss();
            if (aBoolean != null && aBoolean) {
                Toast.makeText(context, "Update Done", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Error: Try Again", Toast.LENGTH_SHORT).show();
            }

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog =new ProgressDialog(context);
            dialog.setCancelable(false);
            dialog.setMessage("Downloading...");
            dialog.setIndeterminate(true);
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            String msg = "";
            int progress = values[0];
            dialog.setProgress(progress);
            if(progress > 99)
                msg = "Finishing...";
            else
                msg = "Dowloading..."+progress;
            dialog.setIndeterminate(false);
            dialog.setMax(100);
            dialog.setMessage(msg);
        }

        @Override
        protected Boolean doInBackground(String... strings) {

           try {
                String PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString()+"/";
                File file = new File(PATH+""+fileName);

                File dir = new File(PATH);
                if(!dir.exists())
                    dir.mkdirs();

                URL u = new URL(url);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                c.setDoOutput(true);
                c.connect();

                FileOutputStream fos = new FileOutputStream(file);

                InputStream is = c.getInputStream();
                float totalSize =(float) c.getContentLength();

                byte[] buffer = new byte[1024];
                int len1 = 0;
                float per ;
                float downloaded = 0f;

                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);
                    downloaded += len1;
                    per = (downloaded * 100 / totalSize);
                    publishProgress((int) per);
                }
                fos.close();
                is.close();
                install(file.getPath());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

}